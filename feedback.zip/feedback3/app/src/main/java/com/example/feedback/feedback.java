package com.example.feedback;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class feedback extends DialogFragment {
    private static final String TAG = "feedback";
    private TextView submitBt;
    private EditText emailEt;
    private EditText feedbackEt;
    public feedback() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.feedback_fragement, container, false);
        submitBt = view.findViewById(R.id.submitBT);
        TextView cancelBt = view.findViewById(R.id.cancelBT);
        emailEt = view.findViewById(R.id.emailET);
        feedbackEt = view.findViewById(R.id.contentET);

        emailEt.addTextChangedListener(feedbackTextWatcher);
        feedbackEt.addTextChangedListener(feedbackTextWatcher);

        cancelBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: closing feedback");
                Toast.makeText(getActivity() , "cancel button clicked", Toast.LENGTH_SHORT).show();
                getDialog().dismiss();
            }
        });
        submitBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: getting feedback");
                Toast.makeText(getActivity() , "submit button clicked", Toast.LENGTH_SHORT).show();

                String email1 = emailEt.getText().toString();
                String content1 = feedbackEt.getText().toString();
                Toast.makeText(getActivity(),"user:"+email1+"\nfeedback:"+content1, Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
    private TextWatcher feedbackTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String email = emailEt.getText().toString().trim();
            String content = feedbackEt.getText().toString().trim();
            submitBt.setEnabled(!email.isEmpty() && !content.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };
}
