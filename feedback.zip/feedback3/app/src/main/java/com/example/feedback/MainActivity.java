package com.example.feedback;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()){
            case R.id.slow:
                Toast.makeText(this, "feedback sent as Slow App", Toast.LENGTH_LONG).show();
                return true;
            case R.id.internet:
                Toast.makeText(this, "feedback sent as No Internet", Toast.LENGTH_LONG).show();
                return true;
            case R.id.custom:
                feedback dialog = new feedback();
                dialog.show(getSupportFragmentManager(),"feedback");
                return true;

        }
        return false;
    }
}
